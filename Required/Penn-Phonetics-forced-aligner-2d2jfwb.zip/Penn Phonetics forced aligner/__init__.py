# This file is a placeholder to allow this directory
# to serve as a Python package, thus allowing e.g.:
#
# from p2tk.python.syllabify import syllabifier
#
# so long as this directory is in your module search
# path (i.e. PYTHONPATH evironment variable) or, say,
# symlinked in the current directory.
